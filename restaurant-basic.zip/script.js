
document.getElementById('kontaktformular').addEventListener('submit', function(e) {
    e.preventDefault();
    alert('Danke für Ihre Nachricht!');
});
